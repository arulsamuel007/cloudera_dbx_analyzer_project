"""
CSV Export Module - Complete Analysis Results

Exports all analysis results to CSV files for easy consumption in Excel,
data analysis tools, or other systems.

Generates multiple CSV files:
1. files_inventory.csv - Complete file listing with all metadata
2. database_tables.csv - All table references with context
3. sql_complexity.csv - SQL query complexity metrics
4. variables.csv - All variables found
5. connections.csv - JDBC, URLs, Kafka, Storage paths
6. master_summary.csv - High-level summary metrics
"""

import csv
import json
from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime


def format_size(bytes_val: int) -> str:
    """Format bytes into human-readable size"""
    if bytes_val is None:
        return ""
    if bytes_val < 1024:
        return f"{bytes_val} B"
    elif bytes_val < 1024 * 1024:
        return f"{bytes_val / 1024:.1f} KB"
    else:
        return f"{bytes_val / (1024 * 1024):.2f} MB"


def export_files_inventory(files_index: List[Dict], output_path: Path) -> int:
    """
    Export complete file inventory to CSV.
    
    Columns:
    - File Path
    - File Name
    - Directory
    - Type
    - Size (Bytes)
    - Size (Formatted)
    - Lines
    - Words
    - Parse Status
    - Has Streaming
    - Has Dynamic SQL
    """
    
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # Header
        writer.writerow([
            'File Path',
            'File Name',
            'Directory',
            'Type',
            'Size (Bytes)',
            'Size (Formatted)',
            'Lines',
            'Words',
            'Parse Status',
            'Has Streaming',
            'Has Dynamic SQL'
        ])
        
        # Data
        for file_info in files_index:
            path = file_info.get('path', '')
            path_obj = Path(path)
            
            writer.writerow([
                path,
                path_obj.name if path else '',
                str(path_obj.parent) if path else '',
                file_info.get('detected_type', ''),
                file_info.get('size_bytes', ''),
                format_size(file_info.get('size_bytes', 0)),
                file_info.get('lines_count', ''),
                file_info.get('words_count', ''),
                file_info.get('parse_status', ''),
                'Yes' if file_info.get('has_streaming') else 'No',
                'Yes' if file_info.get('has_dynamic_sql') else 'No'
            ])
    
    return len(files_index)


def export_database_tables(database_context: Dict, output_path: Path) -> int:
    """
    Export all table references (source and target) to CSV.
    
    Columns:
    - Table Type (Source/Target)
    - Full Name
    - Database
    - Schema
    - Table Name
    - Operation
    - File
    - Line Number
    - Confidence
    - Has Variables
    """
    
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # Header
        writer.writerow([
            'Table Type',
            'Full Name',
            'Database',
            'Schema',
            'Table Name',
            'Operation',
            'File',
            'Line Number',
            'Confidence',
            'Has Variables'
        ])
        
        count = 0
        
        # Source tables
        for table in database_context.get('source_tables', []):
            writer.writerow([
                'Source (Read)',
                table.get('full_name', ''),
                table.get('database', ''),
                table.get('schema', ''),
                table.get('table', ''),
                table.get('operation', ''),
                table.get('file', ''),
                table.get('line_number', ''),
                table.get('confidence', ''),
                'Yes' if table.get('has_variables') else 'No'
            ])
            count += 1
        
        # Target tables
        for table in database_context.get('target_tables', []):
            writer.writerow([
                'Target (Write)',
                table.get('full_name', ''),
                table.get('database', ''),
                table.get('schema', ''),
                table.get('table', ''),
                table.get('operation', ''),
                table.get('file', ''),
                table.get('line_number', ''),
                table.get('confidence', ''),
                'Yes' if table.get('has_variables') else 'No'
            ])
            count += 1
    
    return count


def export_sql_complexity(sql_complexity: Dict, output_path: Path) -> int:
    """
    Export SQL complexity analysis to CSV.
    
    Columns:
    - File
    - Complexity Level
    - Total Score
    - Query Lines
    - Query Length
    - Total JOINs
    - JOIN Types
    - Total Subqueries
    - Max Subquery Depth
    - Correlated Subqueries
    - Total CTEs
    - Recursive CTEs
    - Window Functions
    - Window Function Types
    - Total Aggregates
    - Has GROUP BY
    - Has HAVING
    - Set Operations
    - CASE Statements
    - Has DDL
    - Execution Complexity
    - Risk Flags
    """
    
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # Header
        writer.writerow([
            'File',
            'Complexity Level',
            'Total Score',
            'Query Lines',
            'Query Length (chars)',
            'Total JOINs',
            'JOIN Types',
            'Total Subqueries',
            'Max Subquery Depth',
            'Correlated Subqueries',
            'Total CTEs',
            'Recursive CTEs',
            'Window Functions',
            'Window Function Types',
            'Total Aggregates',
            'Has GROUP BY',
            'Has HAVING',
            'Set Operations',
            'CASE Statements',
            'Has DDL',
            'Execution Complexity',
            'Risk Flags'
        ])
        
        count = 0
        
        # Data
        for query in sql_complexity.get('detailed_results', []):
            join_types = ', '.join(f"{k}:{v}" for k, v in query.get('join_analysis', {}).get('join_types', {}).items())
            window_types = ', '.join(query.get('window_function_analysis', {}).get('window_function_types', []))
            risk_flags = ', '.join(query.get('risk_flags', []))
            
            writer.writerow([
                query.get('file_path', ''),
                query.get('complexity_level', ''),
                query.get('total_complexity_score', ''),
                query.get('query_lines', ''),
                query.get('query_length', ''),
                query.get('join_analysis', {}).get('total_joins', 0),
                join_types,
                query.get('subquery_analysis', {}).get('total_subqueries', 0),
                query.get('subquery_analysis', {}).get('max_nesting_depth', 0),
                query.get('subquery_analysis', {}).get('correlated_subqueries', 0),
                query.get('cte_analysis', {}).get('total_ctes', 0),
                query.get('cte_analysis', {}).get('recursive_ctes', 0),
                query.get('window_function_analysis', {}).get('total_window_functions', 0),
                window_types,
                query.get('aggregate_analysis', {}).get('total_aggregates', 0),
                'Yes' if query.get('aggregate_analysis', {}).get('has_group_by') else 'No',
                'Yes' if query.get('aggregate_analysis', {}).get('has_having') else 'No',
                query.get('set_operation_analysis', {}).get('total_set_operations', 0),
                query.get('control_structure_analysis', {}).get('total_case_statements', 0),
                'Yes' if query.get('ddl_analysis', {}).get('has_create') else 'No',
                query.get('estimated_execution_complexity', ''),
                risk_flags
            ])
            count += 1
    
    return count


def export_variables(database_context: Dict, output_path: Path) -> int:
    """
    Export all variables found to CSV.
    
    Columns:
    - Variable Name
    - Variable Type (hiveconf, hivevar, simple)
    - Usage Count (approximate from tables)
    """
    
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # Header
        writer.writerow([
            'Variable Name',
            'Variable Type',
            'Full Syntax'
        ])
        
        count = 0
        
        # Get variables
        variables = database_context.get('variables_found', [])
        
        for var in variables:
            # Determine type
            if ':' in var:
                var_type = var.split(':')[0]
                var_name = var.split(':', 1)[1]
                full_syntax = f"${{{var}}}"
            else:
                var_type = 'simple'
                var_name = var
                full_syntax = f"${{{var}}}"
            
            writer.writerow([
                var_name,
                var_type,
                full_syntax
            ])
            count += 1
    
    return count


def export_connections(findings: Dict, output_path: Path) -> int:
    """
    Export all connections (JDBC, URLs, Kafka, Storage) to CSV.
    
    Columns:
    - Connection Type
    - Value
    - File
    - Line
    - Confidence
    """
    
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # Header
        writer.writerow([
            'Connection Type',
            'Value',
            'File',
            'Line',
            'Confidence'
        ])
        
        count = 0
        
        # JDBC
        for item in findings.get('jdbc_strings', []):
            writer.writerow([
                'JDBC Connection',
                item.get('value', ''),
                item.get('file', ''),
                item.get('line', ''),
                item.get('confidence', '')
            ])
            count += 1
        
        # URLs
        for item in findings.get('urls', []):
            writer.writerow([
                'URL',
                item.get('value', ''),
                item.get('file', ''),
                item.get('line', ''),
                item.get('confidence', '')
            ])
            count += 1
        
        # Kafka
        for item in findings.get('kafka_bootstrap_hints', []):
            writer.writerow([
                'Kafka Bootstrap Server',
                item.get('value', ''),
                item.get('file', ''),
                item.get('line', ''),
                item.get('confidence', '')
            ])
            count += 1
        
        # Storage Paths
        for item in findings.get('storage_paths', []):
            writer.writerow([
                'Storage Path',
                item.get('value', ''),
                item.get('file', ''),
                item.get('line', ''),
                item.get('confidence', '')
            ])
            count += 1
    
    return count


def export_master_summary(
    repo_summary: Dict,
    database_context: Dict,
    sql_complexity: Dict,
    complexity: Dict,
    output_path: Path
) -> int:
    """
    Export high-level summary metrics to CSV.
    
    Two-column format: Metric Name, Value
    """
    
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # Header
        writer.writerow(['Metric', 'Value'])
        
        # Repository Info
        writer.writerow(['Repository Path', repo_summary.get('repo_root', '')])
        writer.writerow(['Generated At', datetime.fromtimestamp(repo_summary.get('generated_at_epoch', 0)).strftime('%Y-%m-%d %H:%M:%S')])
        writer.writerow(['Analysis Duration (seconds)', repo_summary.get('elapsed_seconds', 0)])
        writer.writerow(['', ''])  # Blank line
        
        # File Statistics
        writer.writerow(['Total Files', repo_summary.get('file_count', 0)])
        writer.writerow(['Oozie Workflows', repo_summary.get('workflow_count', 0)])
        writer.writerow(['Coordinators', repo_summary.get('coordinator_count', 0)])
        writer.writerow(['Bundles', repo_summary.get('bundle_count', 0)])
        writer.writerow(['Has Streaming', 'Yes' if repo_summary.get('has_streaming') else 'No'])
        writer.writerow(['Has Dynamic SQL', 'Yes' if repo_summary.get('has_dynamic_sql') else 'No'])
        writer.writerow(['', ''])
        
        # Database Statistics
        db_summary = database_context.get('summary', {})
        writer.writerow(['Total Databases', db_summary.get('total_databases', 0)])
        writer.writerow(['Total Schemas', db_summary.get('total_schemas', 0)])
        writer.writerow(['Source Table References', db_summary.get('total_source_table_refs', 0)])
        writer.writerow(['Target Table References', db_summary.get('total_target_table_refs', 0)])
        writer.writerow(['Variables Found', db_summary.get('total_variables', 0)])
        writer.writerow(['', ''])
        
        # SQL Complexity Statistics
        if sql_complexity:
            writer.writerow(['SQL Queries Analyzed', sql_complexity.get('queries_analyzed', 0)])
            writer.writerow(['Average SQL Complexity', f"{sql_complexity.get('average_complexity_score', 0):.1f}"])
            
            dist = sql_complexity.get('complexity_distribution', {})
            writer.writerow(['Simple Queries', dist.get('simple', 0)])
            writer.writerow(['Moderate Queries', dist.get('moderate', 0)])
            writer.writerow(['Complex Queries', dist.get('complex', 0)])
            writer.writerow(['Very Complex Queries', dist.get('very_complex', 0)])
            
            metrics = sql_complexity.get('aggregated_metrics', {})
            writer.writerow(['Total JOINs', metrics.get('total_joins', 0)])
            writer.writerow(['Total Subqueries', metrics.get('total_subqueries', 0)])
            writer.writerow(['Total CTEs', metrics.get('total_ctes', 0)])
            writer.writerow(['Total Window Functions', metrics.get('total_window_functions', 0)])
            writer.writerow(['', ''])
        
        # Overall Complexity
        if complexity:
            writer.writerow(['Repository Complexity Level', complexity.get('repo_level', '').upper()])
            writer.writerow(['Repository Complexity Score', complexity.get('repo_score', 0)])
    
    return 1  # One summary file


def export_all_to_csv(artifacts_dir: Path, output_dir: Path) -> Dict[str, int]:
    """
    Export all analysis results to CSV files.
    
    Args:
        artifacts_dir: Path to artifacts directory
        output_dir: Path where CSV files will be saved
        
    Returns:
        Dictionary with counts of exported items per file
    """
    
    # Create output directory
    output_dir.mkdir(parents=True, exist_ok=True)
    
    results = {}
    
    # Load artifacts
    try:
        with open(artifacts_dir / "files_index.json") as f:
            files_index = json.load(f)
    except:
        files_index = []
    
    try:
        with open(artifacts_dir / "database_context.json") as f:
            database_context = json.load(f)
    except:
        database_context = {}
    
    try:
        with open(artifacts_dir / "sql_complexity_analysis.json") as f:
            sql_complexity = json.load(f)
    except:
        sql_complexity = {}
    
    try:
        with open(artifacts_dir / "findings.json") as f:
            findings = json.load(f)
    except:
        findings = {}
    
    try:
        with open(artifacts_dir / "repo_summary.json") as f:
            repo_summary = json.load(f)
    except:
        repo_summary = {}
    
    try:
        with open(artifacts_dir / "complexity.json") as f:
            complexity = json.load(f)
    except:
        complexity = {}
    
    # Export each type
    if files_index:
        count = export_files_inventory(files_index, output_dir / "1_files_inventory.csv")
        results['files_inventory'] = count
    
    if database_context:
        count = export_database_tables(database_context, output_dir / "2_database_tables.csv")
        results['database_tables'] = count
        
        count = export_variables(database_context, output_dir / "5_variables.csv")
        results['variables'] = count
    
    if sql_complexity:
        count = export_sql_complexity(sql_complexity, output_dir / "3_sql_complexity.csv")
        results['sql_complexity'] = count
    
    if findings:
        count = export_connections(findings, output_dir / "4_connections.csv")
        results['connections'] = count
    
    # Always export summary
    count = export_master_summary(repo_summary, database_context, sql_complexity, complexity, output_dir / "0_master_summary.csv")
    results['master_summary'] = count
    
    return results


def export_csv_from_run_dir(run_dir: Path) -> Path:
    """
    Export CSV files from a run directory.
    
    Args:
        run_dir: Path to run directory (e.g., output_files/run_20240101_120000)
        
    Returns:
        Path to CSV export directory
    """
    artifacts_dir = run_dir / "artifacts"
    csv_dir = run_dir / "csv_exports"
    
    results = export_all_to_csv(artifacts_dir, csv_dir)
    
    # Create README
    readme_path = csv_dir / "README.txt"
    with open(readme_path, 'w') as f:
        f.write("CSV Export - Cloudera → Databricks Migration Analysis\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write("Files:\n")
        f.write("------\n")
        f.write("0_master_summary.csv     - High-level summary metrics\n")
        f.write(f"1_files_inventory.csv    - Complete file listing ({results.get('files_inventory', 0)} files)\n")
        f.write(f"2_database_tables.csv    - All table references ({results.get('database_tables', 0)} tables)\n")
        f.write(f"3_sql_complexity.csv     - SQL complexity analysis ({results.get('sql_complexity', 0)} queries)\n")
        f.write(f"4_connections.csv        - JDBC/URLs/Kafka/Storage ({results.get('connections', 0)} items)\n")
        f.write(f"5_variables.csv          - All variables found ({results.get('variables', 0)} variables)\n\n")
        f.write("Usage:\n")
        f.write("------\n")
        f.write("- Open in Excel for analysis\n")
        f.write("- Import into database for querying\n")
        f.write("- Use in data analysis tools (Python, R, etc.)\n")
        f.write("- Share with stakeholders\n")
    
    return csv_dir


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        run_dir = Path(sys.argv[1])
        if run_dir.exists():
            csv_dir = export_csv_from_run_dir(run_dir)
            print(f"✅ CSV exports generated: {csv_dir}")
            print(f"\nFiles created:")
            for f in sorted(csv_dir.glob("*.csv")):
                print(f"  - {f.name}")
        else:
            print(f"❌ Directory not found: {run_dir}")
    else:
        print("Usage: python csv_export.py /path/to/run_directory")
